print("Будут показаны числа, кратные 7")
print("Введите начало и конец диапазона")
beginning = int(input("Введите первое число"))
end = int(input("Введите второе число"))
a = beginning
b = end
for i in range(a, b):
    if i % 7 == 0:
        print(i)







